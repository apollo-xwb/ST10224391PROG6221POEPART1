﻿public class Step
{
    public string Description { get; set; }
}
