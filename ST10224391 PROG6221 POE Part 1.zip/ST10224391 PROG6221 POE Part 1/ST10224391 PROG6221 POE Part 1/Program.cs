﻿using System;
using System.Globalization;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to the Number 1 Recipe App!");

        bool exit = false;

        while (!exit)
        {
            try
            {
                // Accept user input for the number of ingredients and steps
                Console.Write("\nEnter the number of ingredients that would be needed (0 to exit): ");
                int numIngredients = int.Parse(Console.ReadLine());

                if (numIngredients == 0)
                {
                    Console.WriteLine("Exiting...");
                    break;
                }

                Console.Write("Enter the number of steps needed for your recipe: ");
                int numSteps = int.Parse(Console.ReadLine());

                // Create recipe instance
                Recipe recipe = new Recipe(numIngredients, numSteps);

                // Allows user to enter the ingredients
                for (int i = 0; i < numIngredients; i++)
                {
                    Console.WriteLine($"\nEnter the details for the ingredients you've provided {i + 1}:");
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    double quantity;
                    do
                    {
                        Console.Write("Quantity: ");
                    } while (!double.TryParse(Console.ReadLine().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out quantity));
                    Console.Write("Unit of measurement: ");
                    string unit = Console.ReadLine();

                    recipe.AddIngredient(i, name, quantity, unit);
                }

                // Inputs steps
                for (int i = 0; i < numSteps; i++)
                {
                    Console.WriteLine($"\nEnter step {i + 1}:");
                    string description = Console.ReadLine();

                    recipe.AddStep(i, description);
                }

                // Display the recipe
                Console.WriteLine("\nRecipe:");
                recipe.DisplayRecipe();

                // Scales the recipe
                string scaleInput;
                double scale = 1.0;

                do
                {
                    Console.WriteLine("\nWould you like the recipe to be scaled? (Yes/No)");
                    scaleInput = Console.ReadLine().ToLower();

                    if (scaleInput != "yes" && scaleInput != "no" && scaleInput != "y" && scaleInput != "n")
                    {
                        Console.WriteLine("Wrong input. Please enter either 'Yes' or 'No'.");
                    }
                    else if (scaleInput == "yes" || scaleInput == "y")
                    {
                        bool validScale = false;
                        while (!validScale)
                        {
                            Console.WriteLine("Enter your desired scaling factor (0.5 for half, 2 for double, 3 for triple):");
                            string scaleFactorInput = Console.ReadLine();
                            if (double.TryParse(scaleFactorInput.Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out scale) && (scale == 0.5 || scale == 2 || scale == 3))
                            {
                                validScale = true;
                            }
                            else
                            {
                                Console.WriteLine("Wrong input. Please enter either 0.5, 2, or 3.");
                            }
                        }
                    }
                } while (scaleInput != "yes" && scaleInput != "no" && scaleInput != "y" && scaleInput != "n");

                if (scaleInput == "yes" || scaleInput == "y")
                {
                    recipe.ScaleRecipe(scale);

                    Console.WriteLine("\nScaled Recipe:");
                    recipe.DisplayRecipe();
                }

                // Resets quantities
                string resetInput;
                do
                {
                    Console.WriteLine("\nWould you like the quantities to be reset to the original values? (Yes/No)");
                    resetInput = Console.ReadLine().ToLower();

                    if (resetInput != "yes" && resetInput != "no" && resetInput != "y" && resetInput != "n")
                    {
                        Console.WriteLine("Wrong input. Please enter either 'Yes' or 'No'.");
                    }
                } while (resetInput != "yes" && resetInput != "no" && resetInput != "y" && resetInput != "n");

                if (resetInput == "yes" || resetInput == "y")
                {
                    recipe.ResetQuantities();
                    Console.WriteLine("\nQuantities have been successfully reset.");
                }

                // Clears recipe
                string clearInput;
                do
                {
                    Console.WriteLine("\nWould you like the recipe to be cleared to enter a new one? (Yes/No)");
                    clearInput = Console.ReadLine().ToLower();

                    if (clearInput != "yes" && clearInput != "no" && clearInput != "y" && clearInput != "n")
                    {
                        Console.WriteLine("Wrong input. Please enter either 'Yes' or 'No'.");
                    }
                } while (clearInput != "yes" && clearInput != "no" && clearInput != "y" && clearInput != "n");

                if (clearInput == "yes" || clearInput == "y")
                {
                    recipe.ClearRecipe();
                    Console.WriteLine("\nRecipe cleared successfully.");
                }

                // Displays menu
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Enter a new recipe");
                Console.WriteLine("2. Exit");
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    // Allows for a new recipe to be entered
                }
                else if (choice == 2)
                {
                    exit = true;
                    Console.WriteLine("Exiting...");
                }
                else
                {
                    Console.WriteLine("Invalid choice.");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please enter a valid number.");
            }
        }
    }
}

//REFERENCES
//- Troelsen, A.and Japikse, P. 2021. Pro C# 9 with .NET 5: Foundational Principles and Practices in Programming. 10th ed. Apress.
//- Proud, Nick. 2021. "Beginner's Guide to Exception Handling in C#." YouTube video, 26:12.Posted by Nick Proud. January 21, 2021. https://www.youtube.com/watch?v=T_kOi6J0040.
//- C# 9 and .NET 5 – Modern Cross-Platform Development: Build intelligent apps, websites, and services with ASP.NET Core 5, Blazor, Entity Framework Core, and ML.NET using Visual Studio Code" by Mark J. Price.
//- C# 9.0 in a Nutshell: The Definitive Reference" by Joseph Albahari and Eric Johannsen.
//- Programming C# 8.0: Build Cloud, Web, and Desktop Applications" by Ian Griffiths.
//- C# 9.0 Pocket Reference: Instant Help for C# 9.0 Programmers" by Joseph Albahari.