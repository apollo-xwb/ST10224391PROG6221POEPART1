﻿using System;

public class Recipe
{
    private Ingredient[] ingredients;
    private Step[] steps;

    private Ingredient[] originalIngredients;

    public Recipe(int numIngredients, int numSteps)
    {
        ingredients = new Ingredient[numIngredients];
        steps = new Step[numSteps];
        originalIngredients = new Ingredient[numIngredients];
    }

    public void AddIngredient(int index, string name, double quantity, string unit)
    {
        ingredients[index] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
        originalIngredients[index] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
    }

    public void ScaleRecipe(double factor)
    {
        foreach (Ingredient ingredient in ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    public void ResetQuantities()
    {
        for (int i = 0; i < ingredients.Length; i++)
        {
            ingredients[i].Quantity = originalIngredients[i].Quantity;
        }
    }

    public void ClearRecipe()
    {
        Array.Clear(ingredients, 0, ingredients.Length);
        Array.Clear(steps, 0, steps.Length);
    }

    public void AddStep(int index, string description)
    {
        steps[index] = new Step { Description = description };
    }

    public void DisplayRecipe()
    {
        Console.WriteLine("Ingredients Required:");
        foreach (Ingredient ingredient in ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }

        Console.WriteLine("\nSteps To Follow:");
        for (int i = 0; i < steps.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {steps[i].Description}");
        }
    }

}
