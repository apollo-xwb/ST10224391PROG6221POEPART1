﻿using System;

public class Recipe
{
    private Ingredient[] ingredients;
    private Step[] steps;

    private Ingredient[] originalIngredients;

    public Recipe(int numIngredients, int numSteps)
    {
        ingredients = new Ingredient[numIngredients];
        steps = new Step[numSteps];
        originalIngredients = new Ingredient[numIngredients];
    }

    public void AddIngredient(int index, string name, double quantity, string unit)
    {
        ingredients[index] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
        originalIngredients[index] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
    }

    public void ScaleRecipe(double factor)
    {
        foreach (Ingredient ingredient in ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    public void ResetQuantities()
    {
        for (int i = 0; i < ingredients.Length; i++)
        {
            ingredients[i].Quantity = originalIngredients[i].Quantity;
        }
    }

    public void ClearRecipe()
    {
        Array.Clear(ingredients, 0, ingredients.Length);
        Array.Clear(steps, 0, steps.Length);
    }

    public void AddStep(int index, string description)
    {
        steps[index] = new Step { Description = description };
    }

    public void DisplayRecipe()
    {
        Console.WriteLine("Ingredients Required:");
        foreach (Ingredient ingredient in ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }

        Console.WriteLine("\nSteps To Follow:");
        for (int i = 0; i < steps.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {steps[i].Description}");
        }
    }

}

//REFERENCES
//- Troelsen, A.and Japikse, P. 2021. Pro C# 9 with .NET 5: Foundational Principles and Practices in Programming. 10th ed. Apress.
//- Proud, Nick. 2021. "Beginner's Guide to Exception Handling in C#." YouTube video, 26:12.Posted by Nick Proud. January 21, 2021. https://www.youtube.com/watch?v=T_kOi6J0040.
//- C# 9 and .NET 5 – Modern Cross-Platform Development: Build intelligent apps, websites, and services with ASP.NET Core 5, Blazor, Entity Framework Core, and ML.NET using Visual Studio Code" by Mark J. Price.
//- C# 9.0 in a Nutshell: The Definitive Reference" by Joseph Albahari and Eric Johannsen.
//- Programming C# 8.0: Build Cloud, Web, and Desktop Applications" by Ian Griffiths.
//- C# 9.0 Pocket Reference: Instant Help for C# 9.0 Programmers" by Joseph Albahari.